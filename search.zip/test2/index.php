<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style media="screen">
      p
        {
  color: red;
}
    </style>
    <title></title>
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="form-validation.css" rel="stylesheet">
  </head>
  <body class="bg-light">

    <div class="container">
      <div class="py-5 text-center">
        <h2></h2>
      </div>
      <div class="container">
<?php if (isset($_POST['submit'])) {
  include 'config.php';
  $nt="<p>Not Filled</p>" ;
  $roll=$link->real_escape_string($_POST['roll']);
  ?>
  <h2>Roll No: <?php echo $roll; ?></h2>
  <table class="table table-bordered">
    <thead>
    </thead>
    <tbody>
  <?php
  $query = $link->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'student_iitp' AND TABLE_NAME = 'studentinfo'");
  $co=$link->query("SELECT COUNT(*) AS count FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'student_iitp' AND TABLE_NAME = 'studentinfo'");
  $row = mysqli_fetch_array($co);
  $count = $row['count'];
  while($row = $query->fetch_assoc()){
      $result[] = $row;
  }
  $sq = $link->query("SELECT * FROM `studentinfo` WHERE `Roll No`='$roll'");
  $user = $sq->fetch_array();
  if ($user>0) {
  $columnArr = array_column($result, 'COLUMN_NAME');
  $x=0;
  $a=0;
  $countt= $count-1;
  while ($a <= $countt ) {
    ?>
    <tr>
      <th><?php echo  $columnArr[$x] ?></th>
      <td><?php if($user[$x] != ''){
        echo "Filled";}
        else {
          echo $nt;
        } ?></td>
    </tr>
    <?php
    $a++;
    $x++;
  }
  ?>
    </tbody>
  </table>
  </div>
   <br>
   <br>
  <a href="index.php" class="btn btn-danger" type="button">Search More </a>
  <br>
  <br>
  <br>
  <?php
  }
else {
  echo "No record found";
  ?>
  <br>
  <br>
<a href="index.php" class="btn btn-danger" type="button">Search More </a>
  <?php
}
}
 ?>
<?php if (!isset($_POST['submit'])) {
?>
      <div class="row">
        <div class="col-md-12">
          <h4 class="mb-3"></h4>
          <form class="needs-validation" action=""  method="post">
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="firstName">Enter Roll no</label>
                <input type="number" class="form-control" name="roll" required>
              </div>
            </div>
            <hr class="mb-4">
            <button class="btn btn-primary" name="submit" type="submit">Submit</button>
          </form>
        </div>
      </div>
<?php }  ?>
    </div>
    <script src="dist/js/bootstrap.min.js"></script>
  </body>
</html>
